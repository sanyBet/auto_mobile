# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build & Development Commands

```bash
# Install for development
pip install -e ".[dev]"

# Install with all LLM providers
pip install 'droidrun[google,anthropic,openai,deepseek,ollama,dev]'

# Code formatting (Black)
black droidrun

# Linting (Ruff)
ruff check droidrun
ruff check --fix droidrun  # Auto-fix

# Type checking
mypy droidrun

# Security checks (run before PRs)
bandit -r droidrun
safety scan
```

## CLI Usage

```bash
# Run natural language command on device
droidrun run "open settings app"

# List connected devices
droidrun devices

# Device setup
droidrun setup --device <serial>
droidrun ping --device <serial>

# Connect/disconnect TCP
droidrun connect <serial>
droidrun disconnect <serial>
```

Key CLI options: `--provider/-p` (OpenAI, Anthropic, GoogleGenAI, Ollama, DeepSeek), `--model/-m`, `--reasoning/--no-reasoning`, `--vision/--no-vision`, `--debug`, `--ios`

## Architecture Overview

### Agent System (`droidrun/agent/`)

**DroidAgent** (`droid/droid_agent.py`) is the main orchestrator with two execution modes:
- `reasoning=False`: Direct execution via **CodeActAgent** (`codeact/`)
- `reasoning=True`: Planning via **ManagerAgent** (`manager/`) + execution via **ExecutorAgent** (`executor/`)

Specialized agents: **ScripterAgent** (`scripter/`), **TextManipulatorAgent**, **StructuredOutputAgent** (`oneflows/`)

### LLM Integration

Uses `llama-index` for LLM abstraction. Provider names are case-sensitive: `OpenAI`, `Anthropic`, `GoogleGenAI`, `Ollama`, `DeepSeek`, `OpenRouter`

LLM loading: `droidrun/agent/utils/llm_picker.py` (public API), `llm_loader.py` (internal)

### Tools System (`droidrun/tools/`)

- `Tools` - Base interface
- `AdbTools` - Android ADB operations
- `IOSTools` - iOS device operations
- Tool building: `agent/utils/tools.py` → `build_custom_tools()`

### Configuration (`droidrun/config_manager/`)

Pydantic-based YAML configuration. Main class: `DroidrunConfig` in `config_manager.py`

Key configs: `AgentConfig`, `CodeActConfig`, `ManagerConfig`, `ExecutorConfig`, `DeviceConfig`, `TracingConfig`

### Tracing & Telemetry

- Arize Phoenix integration (`agent/utils/tracing_setup.py`)
- PostHog telemetry (`telemetry/`)
- Optional Langfuse support

## Code Style

- Python 3.11+ with type hints
- Line length: 100 (Ruff)
- Formatter: Black
- Import sorting: Ruff (isort rules)
- All contributions in English
